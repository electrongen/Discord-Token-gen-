run install.bat
run CMD.exe with administrator
node .